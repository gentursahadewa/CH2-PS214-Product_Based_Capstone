# Cocok.In
For the capstone project of Bangkit Program 2023 Batch 2
