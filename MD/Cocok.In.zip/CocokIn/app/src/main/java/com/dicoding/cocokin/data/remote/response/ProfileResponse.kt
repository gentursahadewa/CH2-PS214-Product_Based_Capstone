package com.dicoding.cocokin.data.remote.response

class ProfileResponse {
}