package com.dicoding.cocokin.data.dummy

data class ProductDummy(
    val imageId: Int,
    val namaProduk: String,
)
